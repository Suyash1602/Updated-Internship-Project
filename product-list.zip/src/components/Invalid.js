import React from 'react'

function Invalid() {
    return (
        <>
            <div className="m-auto">
                <div className="text-center display-3 text-danger">Invalid URL</div>
                <p className="text-danger text-center display-2">Please enter valid url.</p>
            </div>

        </>
    )
}

export default Invalid